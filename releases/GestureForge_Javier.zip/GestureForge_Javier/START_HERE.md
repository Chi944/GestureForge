# GestureForge — Javier review implementation

Start with `source/docs/javier/USER_GUIDE.md`. Your review implementation includes
viewer/bookmarks, validated portable workspaces, runbook editor/execution,
local shortcuts/Quick Actions, a bounded dispatcher, measured session review,
Windows probes, an integration proposal and a full demo recording draft.

**249 automated tests passed**, including 126 new tests. Ruff, mypy and assignment,
Studio and owned-preview smoke checks passed. Exact commands, package versions and
Linux/Python 3.12 limits are in `source/docs/javier/software-checks.json`.

This is NOT a completed, integrated Windows release. Real Windows 3.11 and both-laptop
launch/Camera/focus/error checks, Deston's shell/readiness attachment, Hau Jie's actual
measured event stream, final acceptance and the real demo recording remain pending.
The source includes an inspection harness; simulation never opens a resource.

## Inspect on your Windows laptop

Open `source` in PowerShell:

```powershell
.\setup.cmd
.\.venv\Scripts\python.exe -m gestureforge.javier_preview
```

Use `--quick-only` to inspect Quick Actions without a deck/runbook. The original
`run.cmd` assignment entry point and `run.cmd --studio` simulation preview are
preserved. For actual OS opening, follow the isolated probe instructions in
`source/docs/javier/USER_GUIDE.md` and `WINDOWS_EVIDENCE.md`. Record actual results;
do not label software mocks or inspection screenshots as Windows evidence.

## Put this work on the real Git branch

The uploaded pack identifies base
`a331d5815b9c0b671601935b06cda8b804798d2c`. GitHub authentication was unavailable here,
so this ZIP contains source and a focused implementation patch, with no synthetic
Git history. It has NOT been pushed or posted as a PR.

1. On an authenticated computer, clone `https://github.com/Chi944/GestureForge_304.git`
   or use your existing clone. Preserve any existing work; do not overwrite it.
2. Fetch `origin`. If Javier's branch already exists, switch to it. Otherwise create
   `codex/javier-shortcuts` from the published `origin/main`. Confirm the branch
   before editing, before committing and before pushing. Never work/push on main
   or Hau Jie's branch.
3. Copy `Javier-implementation.patch` to the parent of your Git repository, then
   run the following from that repository:

```powershell
git fetch origin
git switch -c codex/javier-shortcuts origin/main
# If it already exists, use: git switch codex/javier-shortcuts
git branch --show-current
git status --short
git apply --check ..\Javier-implementation.patch
git apply ..\Javier-implementation.patch
```

This is the NEW focused Javier implementation patch, not the obsolete kickoff
foundation patch. It changes only `viewer.py` among existing source files and adds
owned modules/tests/docs/content. If `--check` fails because the real branch has
advanced or contains conflicting work, stop and resolve the diff with Deston; do
not replace shared source with this old snapshot or force an application.

4. Review the diff and run the team checks:

```powershell
.\.venv\Scripts\python.exe -m ruff check gestureforge tests scripts
.\.venv\Scripts\python.exe -m mypy gestureforge scripts tests
.\.venv\Scripts\python.exe -m pytest -q
.\run.cmd --smoke-test
.\run.cmd --studio --smoke-test
```

5. Confirm `git branch --show-current` says `codex/javier-shortcuts`, stage ONLY the
   reviewed implementation files, and commit. Confirm the branch again before:

```powershell
git push -u origin codex/javier-shortcuts
```

6. Open a PR FROM `codex/javier-shortcuts` INTO `main`, using
   `source/docs/javier/PR_DRAFT.md`. Request Deston's verified GitHub account as
   reviewer and leave it UNMERGED. Deston owns final integration. No force-push.

Read `source/docs/javier/DELIVERY.md` for each task's current coverage and remaining
acceptance. The new `INTERFACE_PROPOSAL.md` is prepared for Deston's review; it has
not been sent through an account. The guide and `VIDEO_DRAFT.md` must be revised
against the accepted final Windows build before recording/submission.
