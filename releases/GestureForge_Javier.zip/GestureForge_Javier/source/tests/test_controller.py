import math
from dataclasses import replace

import pytest

from gestureforge.contracts import Prediction
from gestureforge.controller import Controller


def pred(
    label: str,
    frame_id: int,
    timestamp: float,
    *,
    accepted: bool = True,
    reason: str = "tracking lost",
    session: str = "s1",
) -> Prediction:
    return Prediction(
        session_id=session,
        profile_id="pilot",
        frame_id=frame_id,
        timestamp=timestamp,
        label=label,
        accepted=accepted,
        rejection_reason="" if accepted else reason,
    )


def arm(controller: Controller, start: float = 0.0, frame: int = 1) -> int:
    session = controller.session_id
    controller.process(pred("NEUTRAL", frame, start, session=session), start)
    controller.process(pred("NEUTRAL", frame + 1, start + 0.15, session=session), start + 0.15)
    controller.process(pred("NEUTRAL", frame + 2, start + 0.31, session=session), start + 0.31)
    assert controller.state == "READY"
    return frame + 3


def hold_next(controller: Controller, frame: int, start: float):
    session = controller.session_id
    assert controller.process(pred("NEXT", frame, start, session=session), start) is None
    assert (
        controller.process(pred("NEXT", frame + 1, start + 0.18, session=session), start + 0.18)
        is None
    )
    assert (
        controller.process(pred("NEXT", frame + 2, start + 0.35, session=session), start + 0.35)
        is None
    )
    return controller.process(
        pred("NEXT", frame + 3, start + 0.41, session=session), start + 0.41
    )


def test_next_hold_executes_once_until_neutral_rearms() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)

    event = hold_next(controller, frame, 0.45)
    assert event is not None
    assert event.command == "NEXT"
    assert event.timestamp == 0.86
    assert controller.state == "LATCHED"

    session = controller.session_id
    assert controller.process(pred("NEXT", frame + 4, 1.00, session=session), 1.00) is None
    assert controller.state == "LATCHED"

    controller.process(pred("NEUTRAL", frame + 5, 1.05, session=session), 1.05)
    controller.process(pred("NEUTRAL", frame + 6, 1.20, session=session), 1.20)
    controller.process(pred("NEUTRAL", frame + 7, 1.36, session=session), 1.36)
    assert controller.state == "READY"

    second = hold_next(controller, frame + 8, 1.45)
    assert second is not None
    assert second.event_id != event.event_id


def test_preview_labels_do_not_execute_or_latch() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert controller.process(pred("PREVIOUS", frame, 0.45, session=session), 0.45) is None
    assert controller.state == "READY"
    assert controller.process(pred("BOOKMARK", frame + 1, 0.55, session=session), 0.55) is None
    assert controller.state == "READY"


def test_changed_candidate_cancels_hold() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    controller.process(pred("NEXT", frame, 0.45, session=session), 0.45)
    controller.process(pred("BOOKMARK", frame + 1, 0.60, session=session), 0.60)
    assert controller.process(pred("NEXT", frame + 2, 0.75, session=session), 0.75) is None
    assert controller.state == "CANDIDATE"


def test_brief_classifier_rejection_after_ready_allows_retry() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert (
        controller.process(
            pred("NEXT", frame, 0.45, accepted=False, reason="margin_rejection", session=session),
            0.45,
        )
        is None
    )
    assert controller.state == "READY"

    event = hold_next(controller, frame + 1, 0.55)

    assert event is not None
    assert event.command == "NEXT"
    assert controller.state == "LATCHED"


def test_classifier_rejection_mid_candidate_restarts_full_hold() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert controller.process(pred("NEXT", frame, 0.45, session=session), 0.45) is None
    assert (
        controller.process(
            pred("NEXT", frame + 1, 0.60, accepted=False, reason="margin_rejection", session=session),
            0.60,
        )
        is None
    )
    assert controller.state == "READY"
    assert controller.process(pred("NEXT", frame + 2, 0.65, session=session), 0.65) is None
    assert controller.process(pred("NEXT", frame + 3, 0.84, session=session), 0.84) is None
    assert controller.process(pred("NEXT", frame + 4, 1.03, session=session), 1.03) is None
    assert controller.state == "CANDIDATE"

    event = controller.process(pred("NEXT", frame + 5, 1.06, session=session), 1.06)

    assert event is not None
    assert event.command == "NEXT"
    assert controller.state == "LATCHED"


def test_preview_labels_do_not_unlatch() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert hold_next(controller, frame, 0.45) is not None
    assert controller.process(pred("BOOKMARK", frame + 4, 1.00, session=session), 1.00) is None
    assert controller.state == "LATCHED"


def test_latched_classifier_rejection_jitter_cannot_retrigger() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert hold_next(controller, frame, 0.45) is not None
    assert (
        controller.process(
            pred("NEXT", frame + 4, 1.00, accepted=False, reason="distance_rejection", session=session),
            1.00,
        )
        is None
    )
    assert controller.state == "LATCHED"
    assert controller.process(pred("NEXT", frame + 5, 1.10, session=session), 1.10) is None
    assert controller.state == "LATCHED"


def test_tracking_loss_and_gap_require_neutral_again() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    controller.process(pred("NEXT", frame, 0.45, session=session), 0.45)
    controller.process(pred("NEXT", frame + 1, 0.50, accepted=False, session=session), 0.50)
    assert controller.state == "WAIT_NEUTRAL"

    assert controller.process(pred("NEXT", frame + 2, 0.60, session=session), 0.60) is None
    assert controller.state == "WAIT_NEUTRAL"

    controller.process(pred("NEUTRAL", frame + 3, 0.70, session=session), 0.70)
    controller.process(pred("NEUTRAL", frame + 4, 1.01, session=session), 1.01)
    assert controller.state == "WAIT_NEUTRAL"
    assert controller.last_error

    controller.process(pred("NEUTRAL", frame + 5, 1.20, session=session), 1.20)
    controller.process(pred("NEUTRAL", frame + 6, 1.36, session=session), 1.36)
    controller.process(pred("NEUTRAL", frame + 7, 1.52, session=session), 1.52)
    assert controller.state == "READY"


def test_long_classifier_rejection_after_ready_expires_to_wait_neutral() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    for offset, timestamp in enumerate((0.45, 0.60, 0.76, 0.92)):
        assert (
            controller.process(
                pred(
                    "NEXT",
                    frame + offset,
                    timestamp,
                    accepted=False,
                    reason="distance_rejection",
                    session=session,
                ),
                timestamp,
            )
            is None
        )
    assert controller.state == "READY"

    assert (
        controller.process(
            pred("NEXT", frame + 4, 1.01, accepted=False, reason="distance_rejection", session=session),
            1.01,
        )
        is None
    )
    assert controller.state == "WAIT_NEUTRAL"
    assert controller.process(pred("NEXT", frame + 5, 1.10, session=session), 1.10) is None
    assert controller.state == "WAIT_NEUTRAL"


def test_accepted_next_after_expired_classifier_rejection_still_requires_neutral() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    for offset, timestamp in enumerate((0.45, 0.60, 0.76, 0.92)):
        assert (
            controller.process(
                pred(
                    "NEXT",
                    frame + offset,
                    timestamp,
                    accepted=False,
                    reason="margin_rejection",
                    session=session,
                ),
                timestamp,
            )
            is None
        )
    assert controller.state == "READY"

    assert controller.process(pred("NEXT", frame + 4, 1.10, session=session), 1.10) is None
    assert controller.state == "WAIT_NEUTRAL"
    assert controller.last_error == "classifier rejection grace expired"


def test_stale_future_out_of_order_and_old_session_do_not_execute() -> None:
    controller = Controller("s1")
    controller.resume()
    frame = arm(controller)
    session = controller.session_id

    assert controller.process(pred("NEXT", frame, 0.45, session=session), 0.70) is None
    assert controller.state == "WAIT_NEUTRAL"

    controller.resume()
    frame = arm(controller, start=1.00, frame=10)
    session = controller.session_id
    assert controller.process(pred("NEXT", frame, 1.45, session=session), 1.40) is None
    assert controller.state == "WAIT_NEUTRAL"

    controller.resume()
    frame = arm(controller, start=2.00, frame=20)
    session = controller.session_id
    controller.process(pred("NEXT", frame, 2.45, session=session), 2.45)
    assert controller.process(pred("NEXT", frame, 2.50, session=session), 2.50) is None
    assert controller.state == "WAIT_NEUTRAL"

    controller.resume(session_id="s2")
    assert controller.process(pred("NEXT", 1, 3.00, session="s1"), 3.00) is None
    assert controller.state == "WAIT_NEUTRAL"


def test_resume_without_session_invalidates_queued_predictions() -> None:
    controller = Controller("s1")
    controller.resume(session_id="s1")
    frame = arm(controller)
    queued = pred("NEXT", frame, 0.45, session="s1")

    controller.pause()
    controller.resume()

    assert controller.session_id != "s1"
    assert controller.process(queued, 0.45) is None
    assert controller.state == "WAIT_NEUTRAL"


def test_non_finite_times_are_rejected_and_neutral_can_recover() -> None:
    controller = Controller("s1")
    controller.resume()
    session = controller.session_id

    assert controller.process(pred("NEUTRAL", 1, math.nan, session=session), 0.0) is None
    assert controller.state == "WAIT_NEUTRAL"

    controller.process(pred("NEUTRAL", 2, 1.00, session=session), 1.00)
    controller.process(pred("NEUTRAL", 3, 1.16, session=session), 1.16)
    controller.process(pred("NEUTRAL", 4, 1.31, session=session), 1.31)
    assert controller.state == "READY"


def test_custom_ids_are_exact_immutable_and_guarded_by_model_revision() -> None:
    controller = Controller("s1", executable_gesture_ids=frozenset({"G1", "G2", "G3"}),
                            model_version="model-v2")
    controller.resume("s1")

    def feed(label: str, frame: int, time: float, version: str = "model-v2"):
        return controller.process(replace(pred(label, frame, time), model_version=version), time)

    for frame, time in enumerate((0.0, 0.15, 0.31), 1):
        assert feed("NEUTRAL", frame, time) is None
    assert controller.state == "READY"
    assert feed("g1", 4, 0.45) is None
    assert controller.state == "READY"
    assert feed("UNKNOWN", 5, 0.55) is None
    assert feed("G1", 6, 0.65) is None
    assert feed("G1", 7, 0.80, "old-model") is None
    assert controller.state == "WAIT_NEUTRAL"
    assert feed("G1", 8, 0.95) is None
    assert controller.executable_gesture_ids == frozenset({"G1", "G2", "G3"})
    with pytest.raises(AttributeError):
        setattr(controller, "executable_gesture_ids", frozenset({"NEXT"}))


@pytest.mark.parametrize("ids", [frozenset(), frozenset({"NEUTRAL"}), frozenset({"UNKNOWN"}),
                                frozenset({"g1"}), frozenset({"G1", "G2", "G3", "G4"})])
def test_invalid_executable_ids_are_rejected(ids: frozenset[str]) -> None:
    with pytest.raises(ValueError):
        Controller("s1", executable_gesture_ids=ids)
